var class_red_bot_sensor =
[
    [ "RedBotSensor", "class_red_bot_sensor.html#a2ebbbab14a59c03dde759f693c59ce26", null ],
    [ "check", "class_red_bot_sensor.html#a585a98bb820d20917bb71dfc004cc310", null ],
    [ "read", "class_red_bot_sensor.html#abd97ded86ad9de7e28ad0295a51d5c20", null ],
    [ "setBGLevel", "class_red_bot_sensor.html#aa3e2c32c59f8ac1f9866069602a16eba", null ],
    [ "setDetectLevel", "class_red_bot_sensor.html#a9bbf93b3c4282562e14f605a07f47c64", null ]
];